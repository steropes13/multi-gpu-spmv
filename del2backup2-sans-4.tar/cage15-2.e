src/spmvGPU.cu(28): warning #177-D: variable "globalThread" was declared but never referenced
      int globalThread = blockIdx.x * blockDim.x + threadIdx.x;
          ^

Remark: The warnings can be suppressed with "-diag-suppress <warning-number>"

src/spmvGPU.cu(43): warning #177-D: variable "offset" was declared but never referenced
   int j,offset;
         ^

[edu02:185691:0:185691] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:185692:0:185692] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:185693:0:185693] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:185694:0:185694] Caught signal 7 (Bus error: nonexistent physical address)
--------------------------------------------------------------------------
Primary job  terminated normally, but 1 process returned
a non-zero exit code. Per user-direction, the job has been aborted.
--------------------------------------------------------------------------
--------------------------------------------------------------------------
mpirun noticed that process rank 0 with PID 185691 on node edu02 exited on signal 7 (Bus error).
--------------------------------------------------------------------------
