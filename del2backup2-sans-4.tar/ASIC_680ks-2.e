src/spmvGPU.cu(28): warning #177-D: variable "globalThread" was declared but never referenced
      int globalThread = blockIdx.x * blockDim.x + threadIdx.x;
          ^

Remark: The warnings can be suppressed with "-diag-suppress <warning-number>"

src/spmvGPU.cu(43): warning #177-D: variable "offset" was declared but never referenced
   int j,offset;
         ^

[edu02:182208:0:182208] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:182209:0:182209] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:182210:0:182210] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:182207:0:182207] Caught signal 7 (Bus error: nonexistent physical address)
--------------------------------------------------------------------------
Primary job  terminated normally, but 1 process returned
a non-zero exit code. Per user-direction, the job has been aborted.
--------------------------------------------------------------------------
--------------------------------------------------------------------------
mpirun noticed that process rank 0 with PID 182207 on node edu02 exited on signal 7 (Bus error).
--------------------------------------------------------------------------
