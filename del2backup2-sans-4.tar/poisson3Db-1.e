src/spmvGPU.cu(28): warning #177-D: variable "globalThread" was declared but never referenced
      int globalThread = blockIdx.x * blockDim.x + threadIdx.x;
          ^

Remark: The warnings can be suppressed with "-diag-suppress <warning-number>"

src/spmvGPU.cu(43): warning #177-D: variable "offset" was declared but never referenced
   int j,offset;
         ^

[edu02:186727:0:186727] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:186729:0:186729] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:186732:0:186732] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:186733:0:186733] Caught signal 7 (Bus error: nonexistent physical address)
--------------------------------------------------------------------------
Primary job  terminated normally, but 1 process returned
a non-zero exit code. Per user-direction, the job has been aborted.
--------------------------------------------------------------------------
--------------------------------------------------------------------------
mpirun noticed that process rank 1 with PID 186729 on node edu02 exited on signal 7 (Bus error).
--------------------------------------------------------------------------
