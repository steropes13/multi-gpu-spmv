src/spmvGPU.cu(28): warning #177-D: variable "globalThread" was declared but never referenced
      int globalThread = blockIdx.x * blockDim.x + threadIdx.x;
          ^

Remark: The warnings can be suppressed with "-diag-suppress <warning-number>"

src/spmvGPU.cu(43): warning #177-D: variable "offset" was declared but never referenced
   int j,offset;
         ^

[edu02:186728:0:186728] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:186730:0:186730] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:186731:0:186731] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:186734:0:186734] Caught signal 7 (Bus error: nonexistent physical address)
--------------------------------------------------------------------------
Primary job  terminated normally, but 1 process returned
a non-zero exit code. Per user-direction, the job has been aborted.
--------------------------------------------------------------------------
--------------------------------------------------------------------------
mpirun noticed that process rank 0 with PID 186728 on node edu02 exited on signal 7 (Bus error).
--------------------------------------------------------------------------
