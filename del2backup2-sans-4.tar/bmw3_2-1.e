src/spmvGPU.cu(28): warning #177-D: variable "globalThread" was declared but never referenced
      int globalThread = blockIdx.x * blockDim.x + threadIdx.x;
          ^

Remark: The warnings can be suppressed with "-diag-suppress <warning-number>"

src/spmvGPU.cu(43): warning #177-D: variable "offset" was declared but never referenced
   int j,offset;
         ^

[edu02:185279:0:185279] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:185280:0:185280] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:185281:0:185281] Caught signal 7 (Bus error: nonexistent physical address)
[edu02:185282:0:185282] Caught signal 7 (Bus error: nonexistent physical address)
--------------------------------------------------------------------------
Primary job  terminated normally, but 1 process returned
a non-zero exit code. Per user-direction, the job has been aborted.
--------------------------------------------------------------------------
--------------------------------------------------------------------------
mpirun noticed that process rank 0 with PID 185279 on node edu02 exited on signal 7 (Bus error).
--------------------------------------------------------------------------
