rm: cannot remove 'bin/.nfs800b1d330012e2eb000027b6': Stale file handle
rm: cannot remove 'obj/.nfs800b1d480006332d000027b7': Stale file handle
make: *** [makefile:38: clean] Error 1
--------------------------------------------------------------------------
mpirun was unable to launch the specified application as it could not access
or execute an executable:

Executable: /home/titienjacques.marie/del-2/multi-gpu-spmv/bin/main
Node: edu02

while attempting to start process rank 0.
--------------------------------------------------------------------------
