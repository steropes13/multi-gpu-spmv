Assembler messages:
Fatal error: can't create obj/my_time_lib.o: No such file or directory
make: *** [makefile:26: obj/my_time_lib.o] Error 1
--------------------------------------------------------------------------
mpirun was unable to launch the specified application as it could not access
or execute an executable:

Executable: /home/titienjacques.marie/del-2/multi-gpu-spmv/bin/main
Node: edu02

while attempting to start process rank 0.
--------------------------------------------------------------------------
