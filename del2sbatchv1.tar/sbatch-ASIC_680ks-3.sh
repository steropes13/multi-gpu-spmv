#!/bin/bash
#SBATCH --partition=edu-short
#SBATCH --account=gpu.computing26
#SBATCH --job-name=ASIC_680ks-3
#SBATCH --output=ASIC_680ks-3.o
#SBATCH --error=ASIC_680ks-3.e
#SBATCH --time=00:05:00
#SBATCH --nodes=1
#SBATCH --ntasks=4
#SBATCH --cpus-per-task=1
#SBATCH --gres=gpu:3 #can be changed 
#SBATCH --mem=1G

# Load modules
module load OpenMPI
module load CUDA/12.5.0

# Print compiler versions
gcc --version
mpicc --version



# makefile 
#make 

# Compile
#mpicc /home/titienjacques.marie/del-2/multi-gpu-spmv/main.cu -o /home/titienjacques.marie/del-2/multi-gpu-spmv/bin/main -lcudart -lmpi 


# Build via makefile (no need of mpicc, nvcc does all the job)
make clean && make

#for the MPI-cuda device aware 
export OMPI_MCA_opal_cuda_support=true

#run
mpirun --mca opal_cuda_support 1 -np 3 /home/titienjacques.marie/del-2/multi-gpu-spmv/bin/main /home/titienjacques.marie/del-2/multi-gpu-spmv/ASIC_680ks/ASIC_680ks.mtx

ompi_info | grep -i cuda



    
