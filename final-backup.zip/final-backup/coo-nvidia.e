src/spmvGPU.cu(28): warning #177-D: variable "globalThread" was declared but never referenced
      int globalThread = blockIdx.x * blockDim.x + threadIdx.x;
          ^

Remark: The warnings can be suppressed with "-diag-suppress <warning-number>"

src/spmvGPU.cu(43): warning #177-D: variable "offset" was declared but never referenced
   int j,offset;
         ^

main.cu(383): warning #177-D: variable "totalTime" was declared but never referenced
      float totalTime = 0.0f;
            ^

Remark: The warnings can be suppressed with "-diag-suppress <warning-number>"

main.cu(384): warning #177-D: variable "flops" was declared but never referenced
      double flops = 0.0;
             ^

